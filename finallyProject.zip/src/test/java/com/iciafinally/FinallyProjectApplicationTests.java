package com.iciafinally;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinallyProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
