package com.iciafinally.domain;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter @Setter @ToString
public class Memberchart {
	
	private String chartMonth; 
	private String memberea;
	
	
	
}