package com.iciafinally.controller;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter @Setter @ToString
public class SellerChart {
	
	private String chartMonth; 
	private String product_id;
	
	private String productname;
	private String totalbea;
}