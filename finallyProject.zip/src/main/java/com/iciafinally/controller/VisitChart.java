package com.iciafinally.controller;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter @Setter @ToString
public class VisitChart {

	private String visitday;
	private int visitea;
}